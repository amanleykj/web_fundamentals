
function disappear(e) {
    document.getElementById("donate_button").remove    
}

