function changeText(e){
    e.innerText = 'Logout'
}

function revertText(e){
    e.innerText = 'revert'
}

function clickAlert(){
    alert('Ninja was liked!')
}